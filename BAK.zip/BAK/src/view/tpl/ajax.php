<div id="ajax">

	<?php $this->getBlocs('ajax'); ?>

</div>