<?php if ($elt['value'] != '' && $elt['element_disabled'] != 'Y'){ ?>

	<?php echo $elt['value']; ?>
	
<?php } ?>